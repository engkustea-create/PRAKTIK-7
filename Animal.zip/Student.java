public class Student {

    // Instance Variable
    String nama;
    int kredit;
    double ip;
    int poinMutu;

    // Constructor
    public Student(String nama, int kredit, int poinMutu) {
        this.nama = nama;
        this.kredit = kredit;
        this.poinMutu = poinMutu;
        this.ip = (double) poinMutu / kredit;
    }

    // Method menghitung IP
    public double getIP() {
        return (double) poinMutu / kredit;
    }

    // Method menambahkan kredit dan poin mutu
    public void tambahKredit(int kreditBaru, int poinBaru) {
        kredit += kreditBaru;
        poinMutu += poinBaru;
        ip = (double) poinMutu / kredit;
    }

    // Main Method
    public static void main(String[] args) {

        // Membuat tiga instance Student
        Student mahasiswa1 = new Student("Mary Jones", 14, 46);
        Student mahasiswa2 = new Student("John Stiner", 60, 173);
        Student mahasiswa3 = new Student("Ari Samala", 31, 69);

        // Menambahkan kredit dan poin mutu Ari Samala
        mahasiswa3.tambahKredit(13, 52);

        // Menampilkan data mahasiswa
        System.out.println("=== DATA MAHASISWA ===");

        System.out.println("Nama: " + mahasiswa1.nama);
        System.out.println("Kredit: " + mahasiswa1.kredit);
        System.out.println("Poin Mutu: " + mahasiswa1.poinMutu);
        System.out.println("IP: " + mahasiswa1.getIP());

        System.out.println();

        System.out.println("Nama: " + mahasiswa2.nama);
        System.out.println("Kredit: " + mahasiswa2.kredit);
        System.out.println("Poin Mutu: " + mahasiswa2.poinMutu);
        System.out.println("IP: " + mahasiswa2.getIP());

        System.out.println();

        System.out.println("Nama: " + mahasiswa3.nama);
        System.out.println("Kredit: " + mahasiswa3.kredit);
        System.out.println("Poin Mutu: " + mahasiswa3.poinMutu);
        System.out.println("IP: " + mahasiswa3.getIP());
    }
}